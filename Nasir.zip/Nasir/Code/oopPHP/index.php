<?php
include "init.php";
if(isset($_SESSION['id'])){
    header("location:profile.php");
}
if(isset($_POST['signup'])){

    $data = [
        'name'             => $_POST['full_name'],
        'email'            => $_POST['email'],
        'password'         => $_POST['password'],
        'confirm_password' => $_POST['confirm'],
        'phonenumber'      => $_POST['phonenumber'],
        'address'          => $_POST['address'],
        'country'          => $_POST['country'],
        'state'            => $_POST['state'],
        'name_error'       => '',
        'email_error'      => '',
        'password_error'   => '',
        'confirm_error'    => '',
        'phonenumber_error'=>'',
        'address_error'    =>'',
//        'country_error'    =>'',
//        'state_error'      =>'',


    ];


    /*
         * Name validation
    */
    if(empty($data['name'])){
        $data['name_error'] = "Name is required";
    }

    /*
        * Email validation
    */
    if(empty($data['email'])){
        $data['email_error'] = "Email is required";
    } else {
        if($source->Query("SELECT * FROM users WHERE email = ?", [$data['email']])){
            if($source->CountRows() > 0 ){
                $data['email_error'] = "Sorry email is already exist";
            }
        }
    }

    /*
         * Password validations
    */

    if(empty($data['password'])){
        $data['password_error'] = "Password is required";
    } else if(strlen($data['password']) < 5){
        $data['password_error'] = "Password is too short";
    }

    /*
        * Confirm password validations
    */

    if(empty($data['confirm_password'])){

        $data['confirm_error'] = "Confirm password is required";

    } else if($data['password'] != $data['confirm_password']){
        $data['confirm_error'] = "Confirm password is not matched";
    }

//Phone Number Validation

    if(empty($data['phonenumber'])){
        $data['phonenumber_error'] = "Phone number is required";
    }
// Address Validation
    if(empty($data['address'])){
        $data['address_error'] = "Address is required";
    }
    /*
         * Submit the form
    */

    if(empty($data['name_error']) && empty($data['email_error']) && empty($data['password_error']) && empty($data['confirm_error'])&& empty($data['phonenumber_error']) && empty($data['address_error']) ){
        $password = password_hash($data['password'], PASSWORD_DEFAULT);
        if($source->Query("INSERT INTO users (name,email,password,phonenumber,address,country,state ) VALUES (?,?,?,?,?,?,?)", [$data['name'], $data['email'], $password, $data['phonenumber'], $data['address'], $data['country'], $data['state']])){
            $_SESSION['account_created'] = "Your account is successfully created";
            header("location:login.php");
        }

    }



}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Singup Form</title>
    <link rel="stylesheet" href="assests/css/stylesheet.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway:200,300,400" rel="stylesheet">
</head>
<body>

<div class="container">
    <div class="form">
        <div class="form-section">
            <form action="" method="POST">
                <div class="group">
                    <h3 class="heading">Create account</h3>
                </div>
                <div class="group">
                    <input type="text" name="full_name" class="control" placeholder="Enter Name..." value="<?php if(!empty($data['name'])): echo $data['name']; endif;?>">
                    <div class="error">
                        <?php if(!empty($data['name_error'])): ?>
                            <?php echo $data['name_error']; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="group">
                    <input type="email" name="email" class="control" placeholder="Enter Email..." value="<?php if(!empty($data['email'])): echo $data['email']; endif; ?>">
                    <div class="error">
                        <?php if(!empty($data['email_error'])): ?>
                            <?php echo $data['email_error']; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="group">
                    <input type="password" name="password" class="control" placeholder="Create Password..." value="<?php if(!empty($data['password'])): echo $data['password']; endif; ?>">
                    <div class="error">
                        <?php if(!empty($data['password_error'])): ?>
                            <?php echo $data['password_error']; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="group">
                    <input type="password" name="confirm" class="control" placeholder="Confirm Password..." value="<?php if(!empty($data['confirm_password'])): echo $data['confirm_password']; endif; ?>">
                    <div class="error">
                        <?php if(!empty($data['confirm_error'])): ?>
                            <?php echo $data['confirm_error']; ?>
                        <?php endif; ?>
                    </div>
                </div>

<!--                Extended Code Part start            -->

                <div class="group">
                    <input class="control" placeholder="Enter Phone Number..." type="text" name="phonenumber" >
                    <div class="error">
                        <?php if(!empty($data['phonenumber_error'])): ?>
                            <?php echo $data['phonenumber_error']; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="group">
                    <input class="control" placeholder="Enter Address... " type="text" name="address" >
                    <div class="error">
                        <?php if(!empty($data['address_error'])): ?>
                            <?php echo $data['address_error']; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div>
                    <select  class="control" id="country" placeholder="Country" name="country" onchange="populate(this.id,'state')">

                        <option value="choose"> -- Choose Country -- </option>
                        <option value="india">India</option>
                        <option value="america">America</option>
                        <option value="pakistan">Pakistan</option></select>

                </div>
                <div >

                    <select id="state" class="control" name="state" placeholder="State" class="dropdown">
                        <option value="choose"> -- Choose State -- </option>

                    </select>
                </div>

<!--                Extended Code Part Close            -->

                <div class="group m20">
                    <input type="submit" name="signup" class="btn" value="Create account &rarr;">
                </div>
                <div class="group m20">
                    <a href="login.php" class="link">Already have an account ?</a>
                </div>
            </form>
        </div>
    </div>
</div>


/*
        JavaScript Code Here
*/
<script>
    function populate(s1,s2)
    {
        var s1= document.getElementById(s1);
        var s2= document.getElementById(s2);

        s2.innerHTML = "";
        if(s1.value== "india"){
            var optionArray=['andhra Pradesh|Andhra Pradesh','arunachal Pradesh|Arunachal Pradesh','assam|Assam','bihar|Bihar','chhattisgarh|Chhattisgarh','goa|Goa','gujarat|Gujarat','haryana|Haryana','himachal Pradesh|Himachal Pradesh','jharkhand|Jharkhand','karnataka|Karnataka','kerala|Kerala','madhya Pradesh|Madhya Pradesh','Maharashtra|maharashtra','manipur|Manipur','meghalaya|Meghalaya','mizoram|Mizoram','nagaland|Nagaland','odisha|Odisha','punjab|Punjab','rajasthan|Rajasthan','sikkim|Sikkim','tamil Nadu|Tamil Nadu','telangana|Telangana','tripura|Tripura','uttar Pradesh|Uttar Pradesh','uttarakhand|Uttarakhand','west Bengal|West Bengal'];
        }
        else if(s1.value=='america'){
            var optionArray=['alabama|Alabama','alaska|Alaska','arizona|Arizona','arkansas|Arkansas','california|California','colorado|Colorado','connecticut|Connecticut','delaware|Delaware','florida|Florida','georgia|Georgia','hawaii|Hawaii','idaho|Idaho','illinois|Illinois','indiana|Indiana','iowa|Iowa','kansas|Kansas','kentucky|Kentucky','louisiana|Louisiana','maine|Maine','maryland|Maryland','massachusetts|Massachusetts','michigan|Michigan','minnesota|Minnesota','mississippi|Mississippi','missouri|Missouri','montana|Montana','nebraska|Nebraska','nevada|Nevada','new Hampshire|New Hampshire','new Jersey|New Jersey','new Mexico|New Mexico','new York|New York','north Carolina|North Carolina','north Dakota|North Dakota','ohio|Ohio','oklahoma|Oklahoma','oregon|Oregon','pennsylvania|Pennsylvania','rhode Island|Rhode Island','south Carolina|South Carolina','south Dakota|South Dakota','tennessee|Tennessee','texas|Texas','utah|Utah','vermont|Vermont','virginia|Virginia','washington|Washington','west Virginia|West Virginia','wisconsin|Wisconsin','wyoming|Wyoming'];
        }  else if(s1.value=='pakistan'){
            var optionArray=['azad Kashmir|Azad Kashmir','balochistan|Balochistan','gilgit-Baltistan|Gilgit-Baltistan','khyber Pakhtunkhwa|Khyber Pakhtunkhwa','punjab|Punjab','sindh|Sindh'];
        }
        for(var option in optionArray)
        {
            var pair=optionArray[option].split("|");
            var newoption= document.createElement("option");

            newoption.value= pair[0];
            newoption.innerHTML=pair[1];
            s2.options.add(newoption);
        }
    }
</script>

</body>
</html>