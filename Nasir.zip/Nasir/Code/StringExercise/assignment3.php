<?php
$string = 'The quick brown fox jumps over the lazy dog.';
if (strpos($string,'jumps') !== false) 
 {
    echo ' word is present.';
 }
else
 {
    echo 'word is not present.';
 }

?>
