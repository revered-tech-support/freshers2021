<?php
$string = 'football';
$string2 = 'footboll';
$str_pos = strspn($string ^ $string2, "\0");
printf('First difference  2 strings at position %d: "%s" vs "%s"',
$str_pos, $string[$str_pos], $string2[$str_pos]);
printf("\n");
?>