<?php
$char = 'a';
$new_char = ++$char; 
if (strlen($new_char) > 1) 
{
 $new_char = $new_char[0];
 }
echo "Next Char: ".$new_char."<br>";
?>