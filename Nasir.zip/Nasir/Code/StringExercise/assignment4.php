<?php
$number = 50;
$string = (string)$number;
if($number == $string)
{
    echo "String and number are same";
}
else{
    echo "String and number are not same";
}
?>