<?php
$simstr = 'rayy@example.com';

echo substr($simstr, 13, 4);
?>