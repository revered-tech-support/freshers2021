<?php
$string = 'the quick brown fox jumps over the lazy dog.';
echo str_replace('the', 'That', $string)."<br>"; 
?>
