<?php
$x = array(1, 2, 3, 4, 5);
unset($x[3]);
echo "$x[0],$x[1],$x[2],$x[4]";
?>