<?php
$color = array('white', 'green', 'red', 'blue', 'black');
echo "The memory of that scene for me is like a frame of film forever frozen at that moment: the $color[2] carpet, the $color[1] lawn, the $color[0] house, the leaden $color[3] sky. The new president and his first $color[4] lady. - Richard M. Nixon"."\n";
?>