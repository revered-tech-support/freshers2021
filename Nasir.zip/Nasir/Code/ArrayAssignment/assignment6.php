<?php
$ar = array( '1','2','3','4','5' );
echo 'Original array : '."<br>";
foreach ($ar as $i) 
{echo "$i ";}
$newItem = '$';
array_splice( $ar, 3, 0, $newItem ); 
echo " <br> After inserting '$' the array is : "."<br>";
foreach ($ar as $i) 
{echo "$i ";}
echo "<br>"
?>