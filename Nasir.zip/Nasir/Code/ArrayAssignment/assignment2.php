<?php

 $color = array('white', 'green', 'red');

 echo "$color[1]"."<br>" ."$color[2]"."<br>" ."$color[0]";

?>