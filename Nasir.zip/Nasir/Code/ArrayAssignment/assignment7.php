<?php
echo "Associative array : Ascending order sort by value"."<br>";

$av=array("Sophia"=>"31","Jacob"=>"41","William"=>"39","Ramesh"=>"40"); asort($av);
foreach($av as $y=>$y_value)
{
echo "Age of ".$y." is : ".$y_value."<br>";
}
echo "<br>Associative array : Ascending order sort by Key"."<br>";

$ak=array("Sophia"=>"31","Jacob"=>"41","William"=>"39","Ramesh"=>"40"); ksort($ak);
foreach($ak as $y=>$y_value)
{
echo "Age of ".$y." is : ".$y_value."<br>";
}
echo "<br>Associative array : Descending order sorting by Value"."<br>";

$dv=array("Sophia"=>"31","Jacob"=>"41","William"=>"39","Ramesh"=>"40");arsort($dv);
foreach($dv as $y=>$y_value)
{
echo "Age of ".$y." is : ".$y_value."<br>";
}
echo "<br>Associative array : Descending order sorting by Key"."<br>";

$dk=array("Sophia"=>"31","Jacob"=>"41","William"=>"39","Ramesh"=>"40"); krsort($dk);
foreach($dk as $y=>$y_value)
{
echo "Age of ".$y." is : ".$y_value."<br>";
} 
?>
