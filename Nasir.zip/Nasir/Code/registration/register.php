<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>Register Page</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="header">
		<h2>Register</h2>
	</div>

	<form method="post" action="register.php">
		<?php include('errors.php') ?>
		<div class="input-group">
			<label>Username</label>
			<input type="text" name="username" >
		</div>
		<div class="input-group">
			<label>Email</label>
			<input type="email" name="email">
		</div>
		<div class="input-group">
			<label>Password</label>
			<input type="password" name="password_1">
		</div>
		<div class="input-group">
			<label>Confirm password</label>
			<input type="password" name="password_2">
		</div>
		
        <div class="input-group">
            <label for="phonenumber">Phone number: </label>
            <input type="text" name="phonenumber" >
		</div>
        <div class="input-group">
            <label for="address">Address : </label>
            <input type="text" name="address" >
         </div>

		 <div>
                <label for="Country"> Country : </label>
                    <select class="dropdown" id="country" name="country" onchange="populate(this.id,'state')">
                         
					<option value="choose"> -- Choose Country -- </option>
					<option value="india">India</option>
                    <option value="america">America</option>
                    <option value="pakistan">Pakistan</option></select>
                    
             </div>
            <div >
                    <label for="State"> State : </label>
                        <select id="state" name="state"  class="dropdown">
						<option value="choose"> -- Choose State -- </option>
                          
                    </select>
             </div>

		 <div class="" >
			<button type="submit" class="btn" name="reg_user">Register</button>
		</div>

		<p>
			Already a member? <a href="login.php">Sign in</a>
		</p>
	</form>

	<script>
        function populate(s1,s2)
        {
            var s1= document.getElementById(s1);
            var s2= document.getElementById(s2);

            s2.innerHTML = "";
            if(s1.value== "india"){
                var optionArray=['andhra Pradesh|Andhra Pradesh','arunachal Pradesh|Arunachal Pradesh','assam|Assam','bihar|Bihar','chhattisgarh|Chhattisgarh','goa|Goa','gujarat|Gujarat','haryana|Haryana','himachal Pradesh|Himachal Pradesh','jharkhand|Jharkhand','karnataka|Karnataka','kerala|Kerala','madhya Pradesh|Madhya Pradesh','Maharashtra|maharashtra','manipur|Manipur','meghalaya|Meghalaya','mizoram|Mizoram','nagaland|Nagaland','odisha|Odisha','punjab|Punjab','rajasthan|Rajasthan','sikkim|Sikkim','tamil Nadu|Tamil Nadu','telangana|Telangana','tripura|Tripura','uttar Pradesh|Uttar Pradesh','uttarakhand|Uttarakhand','west Bengal|West Bengal'];
            }
            else if(s1.value=='america'){
                var optionArray=['alabama|Alabama','alaska|Alaska','arizona|Arizona','arkansas|Arkansas','california|California','colorado|Colorado','connecticut|Connecticut','delaware|Delaware','florida|Florida','georgia|Georgia','hawaii|Hawaii','idaho|Idaho','illinois|Illinois','indiana|Indiana','iowa|Iowa','kansas|Kansas','kentucky|Kentucky','louisiana|Louisiana','maine|Maine','maryland|Maryland','massachusetts|Massachusetts','michigan|Michigan','minnesota|Minnesota','mississippi|Mississippi','missouri|Missouri','montana|Montana','nebraska|Nebraska','nevada|Nevada','new Hampshire|New Hampshire','new Jersey|New Jersey','new Mexico|New Mexico','new York|New York','north Carolina|North Carolina','north Dakota|North Dakota','ohio|Ohio','oklahoma|Oklahoma','oregon|Oregon','pennsylvania|Pennsylvania','rhode Island|Rhode Island','south Carolina|South Carolina','south Dakota|South Dakota','tennessee|Tennessee','texas|Texas','utah|Utah','vermont|Vermont','virginia|Virginia','washington|Washington','west Virginia|West Virginia','wisconsin|Wisconsin','wyoming|Wyoming'];
            }  else if(s1.value=='pakistan'){
                var optionArray=['azad Kashmir|Azad Kashmir','balochistan|Balochistan','gilgit-Baltistan|Gilgit-Baltistan','khyber Pakhtunkhwa|Khyber Pakhtunkhwa','punjab|Punjab','sindh|Sindh'];
            }
            for(var option in optionArray)
            {
                var pair=optionArray[option].split("|");
                var newoption= document.createElement("option");

                newoption.value= pair[0];
                newoption.innerHTML=pair[1];
                s2.options.add(newoption);
            }
        }
    </script>
</body>
</html>