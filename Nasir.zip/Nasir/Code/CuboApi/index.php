
<html>
<head>
	<title></title>
</head>
<body>

    <form action="test-curl.php" method="POST">
        <h1>Enter your Payment Details </h1>
        <pre>
Enter Username : <input type="text" name="username" maxlength="8" required> <br>

Amount to be Paid : <input type="text" name="amount" required> <br>
         <input type="hidden" name="form_submitted" value="1" />

        <input type="submit" value="submit">

        </pre>
    </form>
</body>
</html>