<?php

include 'index.php';
$invoice=$_POST['username'];
$amount=$_POST['amount'];


function CallAPI($method, $url, $data )
{
    $curl = curl_init();

	curl_setopt($curl, CURLOPT_HTTPHEADER, array(
		'Content-Type: application/json',
	));


switch ($method)
{
	case "POST":
		curl_setopt($curl, CURLOPT_POST, 1);

		if ($data)
			curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
		break;
	case "PUT":
		curl_setopt($curl, CURLOPT_PUT, 1);
		break;
	default:
		if ($data)
			$url = sprintf("%s?%s", $url, http_build_query($data));
}


    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

    $result = curl_exec($curl);

    curl_close($curl);

    return $result;
}

$data='{
    "api_key": "zR4dVfGuQ9ENHCk5TBimoSKZrbv30Y",
    "invoice": "'.$invoice.'",
    "amount":"'.$amount.'",
    "select": "3",
    "url_retorn": "https://yoursite.com",
    "description": "Payment Invoice# '.$invoice.'"
}';



$response = CallAPI("POST", "https://cubopay.net/api/checkout/Generate", $data);



$response_array = json_decode($response);
echo "<pre>";
//print_r($response_array);


echo $response_array->Message;
if($response_array->Status=="200")
{
	//echo $response_array->Payment_Url;
   header("Location:$response_array->Payment_Url");
}
elseif($response_array->Status!="200")
{
    echo "<br>There has been an error"."<br>". $response_array->Message ."<br> Can you please correct the information & try again ? ";	

 }


?>