<?php
$wsite = 'https://www.w3resource.com/index.php';

echo $wsite."<br>";
$pname = basename($wsite, ".php"); 
echo $pname."<br>";
?>