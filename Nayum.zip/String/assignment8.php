<?php
$num = 65.45;
$num1 = 104.35;

echo sprintf("%1.2f",$num+$num1);
?>