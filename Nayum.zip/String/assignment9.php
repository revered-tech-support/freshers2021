<?php
function pass($char) 
{
  $string = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz';
  return substr(str_shuffle($string), 0, $char);
}
  echo pass(8)."\n";
?>