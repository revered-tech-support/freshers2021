<?php
echo ("string all uppercase letters")."<br>";
print(strtoupper("good morning."))."<br>";
echo("string in lowercase letters")."<br>";
print(strtolower("GOOD AFTERNOON"))."<br>";
echo("String's first character uppercase")."<br>";
print(ucfirst("good evening"))."<br>";
echo("string's first character of all the words uppercase")."<br>";
print(ucwords("good night and sweets dreams"))."<br>";
?>