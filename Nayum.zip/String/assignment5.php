<?php
$string1  = 'www.example.com/public_html/index.php';
$fname = substr(strrchr($string1,'/'),1);
echo $fname;
?>