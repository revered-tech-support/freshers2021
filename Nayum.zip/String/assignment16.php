<?php
$string = 'rayy@example.com';
echo bin2hex($string)."<br>";
?>