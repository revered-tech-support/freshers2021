<?php

namespace  Nasir\Hellow\Controller\says;
class Helloworld extends \Magento\Framework\App\Action\Action
{
    public function execute()
    {
        // TODO: Implement execute() method.

        echo "Hello World";
    }
}
