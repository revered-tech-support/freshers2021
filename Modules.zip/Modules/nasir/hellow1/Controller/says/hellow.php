<?php

namespace  nasir\hellow1\Controller\says;

class hellow extends \Magento\Framework\App\Action\Action
{
    public function execute()
    {
        // TODO: Implement execute() method.

        echo "Hello World";
    }
}
