<?php

namespace nasir\hellow1\Controller\is;

class punctual extends \Magento\Framework\App\Action\Action
{
    public function execute()
    {
        // TODO: Implement execute() method.

        echo "Hello World";
    }
}
