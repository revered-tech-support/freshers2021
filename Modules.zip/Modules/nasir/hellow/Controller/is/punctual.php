<?php

namespace nasir\hellow\Controller\is;

class punctual extends \Magento\Framework\App\Action\Action
{
    public function execute()
    {
        // TODO: Implement execute() method.

        echo "Hello World";
    }
}
