<?php

namespace  nasir\hellow\Controller\says;

class hellow extends \Magento\Framework\App\Action\Action
{
    public function execute()
    {
        // TODO: Implement execute() method.

        echo "Hello World";
    }
}
