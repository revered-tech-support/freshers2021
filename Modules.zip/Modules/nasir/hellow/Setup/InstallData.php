<?php

namespace nasir\hellow\Setup;

use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

class InstallData implements InstallDataInterface
{
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $dataUserRows = [
            [
                'name' => 'Nasirahmed Sayyed',
                'address' => 'Maharashtra India',
                'email' => 'nasir@test.com'
            ],
            [
                'name' => 'Nayum Shaikh',
                'address' => 'Maharashtra India',
                'email' => 'nayum@test.com'
            ],
            [
                'name' => 'Fayz Hasan',
                'address' => 'London UK',
                'email' => 'fayz@test.com'
            ]

        ];

        foreach($dataUserRows as $data) {
            $setup->getConnection()->insert($setup->getTable('user_info'), $data);
        }
    }
}
?>
