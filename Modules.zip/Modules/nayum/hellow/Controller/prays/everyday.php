<?php

namespace  nayum\hellow\Controller\prays;
class everyday extends \Magento\Framework\App\Action\Action
{
    public function execute()
    {
        // TODO: Implement execute() method.

        echo "Hello World";
    }
}
