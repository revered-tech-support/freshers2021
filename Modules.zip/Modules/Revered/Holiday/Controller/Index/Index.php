<?php

namespace Revered\Holiday\Controller\Index;

use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultFactory;

class Index extends \Magento\Framework\App\Action\Action
{

    public function execute()
    {
        // TODO: Implement execute() method.
        // $result = $this->resultFactory->create(ResultFactory::TYPE_RAW);
        // $result->setContents('Hello Nasir ');
        // return $result;
        // echo "Hello";
        return $this->resultFactory->create(ResultFactory::TYPE_PAGE);


    }
}

