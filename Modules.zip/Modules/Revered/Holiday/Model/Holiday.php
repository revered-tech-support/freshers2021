<?php
namespace Revered\Holiday\Model;

//use Revered\Holiday\Model\ResourceModel\Holiday as HolidayResource;

class Holiday extends \Magento\Framework\Model\AbstractModel
{
    protected function _construct()
    {
        $this->_init(\Revered\Holiday\Model\ResourceModel\Holiday::class);
    }
}
