<?php
namespace Revered\Holiday\Model\ResourceModel\Holiday;

//use Revered\Holiday\Model\Holiday as Model;
use Revered\Holiday\Model\Holiday;
use Revered\Holiday\Model\ResourceModel\Holiday as HolidayResource;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'id';
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
// $this->_init('Revered\Holiday\Model\Holiday', 'Revered\Holiday\Model\ResourceModel\Holiday');

        $this->_init(Holiday::class, HolidayResource::class);   //Here I used Model instead Of Holiday
    }
}
