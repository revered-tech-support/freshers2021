<?php

namespace Revered\Holiday\Setup;

use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;

class UpgradeData implements UpgradeDataInterface
{

    protected $date;
    public function __construct(
        \Magento\Framework\Stdlib\DateTime\DateTime $date
    ) {
        $this->date = $date;
    }
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        if (version_compare($context->getVersion(), '1.0.1', '<')) {
            $data = [
                        'holidayname' => 'Ganpati',
                        'holidaytype' => 'Religious holidays',
                        'Date' =>  ' 2021-09-25 00:00:00'
            ];
            $table=$setup->getTable('holiday_list');
            $setup->getConnection()
                ->update($table, ['Date' => '2021-09-15'], 'holidayname LIKE "%Independence Day%"');
                $setup->getConnection()
                ->update($table, ['Date' => '2021-01-26'], 'holidayname LIKE "%Republic Day%"');
                $setup->getConnection()
                ->update($table, ['Date' => '2021-04-05'], 'holidayname LIKE "%Eid al-Fitr%"');
                $setup->getConnection()
                ->update($table, ['Date' => '2021-06-24'], 'holidayname LIKE "%Eid al-Adha%"');
              $setup->getConnection()
                  ->update($table, ['Date' => '2021-10-25'], 'holidayname LIKE "%Diwali%"');
              $setup->getConnection()->insert($setup->getTable('holiday_list'), $data);
        }
        $setup->endSetup();
    }
}
