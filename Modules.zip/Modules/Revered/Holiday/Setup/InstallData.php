<?php

namespace Revered\Holiday\Setup;

use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

class InstallData implements InstallDataInterface
{
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $dataUserRows = [
            [
                'holidayname' => 'Independence Day',
                'holidaytype' => 'National holidays.',

            ],
            [
                'holidayname' => 'Republic Day',
                'holidaytype' => 'National holidays.',

            ],
            [
                'holidayname' => 'Eid al-Fitr',
                'holidaytype' => 'Religious holidays',

            ],
            [
                'holidayname' => 'Eid al-Adha',
                'holidaytype' => 'Religious holidays',

            ],
            [
                'holidayname' => 'Diwali',
                'holidaytype' => 'Religious holidays',

            ]

        ];

        foreach($dataUserRows as $data) {
            $setup->getConnection()->insert($setup->getTable('holiday_list'), $data);
        }
    }
}
