<?php
namespace Revered\Holiday\Block;

use Revered\Holiday\Model\ResourceModel\Holiday\Collection;
use Revered\Holiday\Model\ResourceModel\Holiday\CollectionFactory;
use Magento\Framework\View\Element\Template;

class Empdata extends Template
{
    private $collectionFactory; //Here i used, private CollectionFactory $collectionFactory
    public function __construct(
        Template\Context  $context,
        CollectionFactory $collectionFactory,
        array $data = []
    )
    {
        $this->collectionFactory = $collectionFactory;
        parent::__construct($context, $data);
    }
    public function getHolidayList()
    {
       //return __('Hello World');
        return $this->collectionFactory->create()->getItems();
    }
}

